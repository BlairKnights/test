enum Color {
    Red,
    Green,
    White,
    Blue,
}

console.log("\n List of colors:",Color);
let green: Color = Color.Green;
  
console.log("Selected Color:", green,"\n");
  
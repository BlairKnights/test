"use strict";
var Name = "abc";
var age = 21;
console.log("\n Name: " + Name + "\n Age: " + age + "\n");

"use strict";
var x = "1000";
var y = parseInt(x);
console.log("\n Number from assertion:", y);
var a = 2000;
var b = a.toString();
console.log(" String from assertion:", b, "\n");

export const hello = 'Hello,';
export const name = 'TypeScript!';

export function add(a: number, b: number): number {
  return a + b;
}

export function greet(name: string): string {
  return `Hello, ${name}!`;
}

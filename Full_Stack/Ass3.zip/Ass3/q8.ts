import {Student} from './q8student';

const student1 = new Student('Doris Mauri', 18);
const student2 = new Student('Joel Darinka', 20);

console.log();
student1.displayInfo();
student2.displayInfo();
console.log();
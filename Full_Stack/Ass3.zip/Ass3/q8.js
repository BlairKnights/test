"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var q8student_1 = require("./q8student");
var student1 = new q8student_1.Student('Doris Mauri', 18);
var student2 = new q8student_1.Student('Joel Darinka', 20);
console.log();
student1.displayInfo();
student2.displayInfo();
console.log();

import { sayHelloFromA } from './q11test_module_a';
console.log();
sayHelloFromA();
console.log();
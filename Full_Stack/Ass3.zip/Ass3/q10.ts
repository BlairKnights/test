import greet from './q10test_module';

console.log("\n",greet('Francis'),"\n");  
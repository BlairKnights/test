"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var q11test_module_a_1 = require("./q11test_module_a");
console.log();
(0, q11test_module_a_1.sayHelloFromA)();
console.log();

let Name: string = "abc";
let age: number = 21;

console.log("\n Name: "+Name+"\n Age: "+age+"\n");
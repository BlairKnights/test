"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var q9test_module_1 = require("./q9test_module");
console.log();
console.log(q9test_module_1.hello, q9test_module_1.name);
console.log((0, q9test_module_1.add)(6, 8));
console.log((0, q9test_module_1.greet)('abc'), "\n");

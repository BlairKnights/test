"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sayHelloFromB = void 0;
function sayHelloFromB() {
    console.log('Hello from module B');
}
exports.sayHelloFromB = sayHelloFromB;

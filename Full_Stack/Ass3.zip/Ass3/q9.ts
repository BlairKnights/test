import { hello, name, add, greet } from './q9test_module';

console.log();
console.log(hello, name);  
console.log(add(6, 8));  
console.log(greet('abc'),"\n"); 

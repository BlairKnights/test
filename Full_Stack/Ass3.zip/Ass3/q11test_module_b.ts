import { sayHelloFromA } from './q11test_module_a';
export function sayHelloFromB() {
  console.log('Hello from module B');
}

let x: string = "1000";
let y: number = parseInt(x);
console.log("\n Number from assertion:", y);

let a: number = 2000;
let b: string = a.toString(); 
console.log(" String from assertion:", b,"\n");

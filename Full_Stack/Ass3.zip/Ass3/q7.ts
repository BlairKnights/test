class Engine 
{
    horsepower: number;
    fuelType: string;
  
    constructor(horsepower: number, fuelType: string) 
    {
        this.horsepower = horsepower;
        this.fuelType = fuelType;   
    }
}
  
class Car 
{
    make: string;
    model: string;
    year: number;
    engine: Engine;
  
    constructor(make: string, model: string, year: number, engine: Engine) 
    {
        this.make = make;
        this.model = model;
        this.year = year;
        this.engine = engine;
    }
  
    start() 
    {
        console.log(`\nThe ${this.make} ${this.model} (Year: ${this.year}) is starting.`);
    }
  
    printCarDetails() 
    {
        console.log(`\nCar Details:`);
        console.log(`Make: ${this.make}`);
        console.log(`Model: ${this.model}`);
        console.log(`Year: ${this.year}`);
        console.log(`Engine Details:`);
        console.log(`Horsepower: ${this.engine.horsepower}`);
        console.log(`Fuel Type: ${this.engine.fuelType}\n`);
    }
}
  
const myEngine = new Engine(200, "Gasoline");
const myCar = new Car("Audi", "A3", 2023, myEngine);
myCar.start();
myCar.printCarDetails();  
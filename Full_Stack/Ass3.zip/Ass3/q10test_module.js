"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function greet(name) {
    return "Hello, ".concat(name, "!");
}
exports.default = greet;

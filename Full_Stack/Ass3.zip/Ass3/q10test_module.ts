export default function greet(name: string): string {
    return `Hello, ${name}!`;
  }
  
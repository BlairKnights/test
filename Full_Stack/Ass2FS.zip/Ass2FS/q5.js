let text = "abc\ndef\nghi";
arr = text.split("\n");
console.log(`\n Original string:\n${text}\n after spliting: `);
console.log(arr);
console.log("\n");
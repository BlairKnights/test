
const { displayTotal } = require('./q22main.js');

displayTotal("hELLO",3.143,2);
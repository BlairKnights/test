const math = require('./math'); 

const result1 = math.add(5, 3);
const result2 = math.subtract(5, 3);

console.log(`Sum: ${result1}`);
console.log(`Difference: ${result2}`);
